
$(document).ready( function () {
    $('#notas_alumnos').DataTable({
        columns: [
            
        ]
    });
    //$('#myTable').DataTable();
} );